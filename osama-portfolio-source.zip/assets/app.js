
// Square grid background is pure CSS (.pf-dust pseudo-elements)
    document.querySelectorAll('[data-scroll]').forEach(function (b) {
        b.addEventListener('click', function () {
            var el = document.getElementById(b.getAttribute('data-scroll'));
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });
    var grid = document.getElementById('pf-grid');
    if (grid) {
        var cards = Array.from(grid.querySelectorAll('.pf-card'));
        var search = document.getElementById('pf-search');
        var count = document.getElementById('pf-count');
        var empty = document.getElementById('pf-empty');
        var active = 'الكل';
        function apply() {
            var q = (search.value || '').trim().toLowerCase();
            var shown = 0;
            cards.forEach(function (c) {
                var ok = (active === 'الكل' || c.dataset.cat === active) &&
                    (!q || c.dataset.title.indexOf(q) !== -1 || c.dataset.cat.indexOf(search.value.trim()) !== -1);
                c.style.display = ok ? '' : 'none';
                if (ok) shown++;
            });
            count.textContent = shown + ' من ' + cards.length + ' مشروع';
            empty.hidden = shown !== 0;
        }
        search.addEventListener('input', apply);
        document.querySelectorAll('.pf-filter').forEach(function (f) {
            f.addEventListener('click', function () {
                document.querySelectorAll('.pf-filter').forEach(function (x) { x.classList.remove('is-active'); });
                f.classList.add('is-active');
                active = f.dataset.cat;
                apply();
            });
        });
    }
})();
